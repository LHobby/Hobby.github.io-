//models/shopsSchema.js
const mongoose = require('mongoose');
const shopsSchema = mongoose.Schema({  
    img: String,
    detail: String,
    price: Number,
    type: String
}, { collection: 'shops' })
const User = module.exports = mongoose.model('shops', shopsSchema);