//models/shopsSchema.js
const mongoose = require('mongoose');
const usersSchema = mongoose.Schema({  
    userid: String,
    roleid: String
}, { collection: 'power' })
const User = module.exports = mongoose.model('power', usersSchema);