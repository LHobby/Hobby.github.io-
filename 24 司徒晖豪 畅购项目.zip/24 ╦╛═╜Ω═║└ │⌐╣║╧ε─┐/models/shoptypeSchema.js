//models/shopsSchema.js
const mongoose = require('mongoose');
const userSchema = mongoose.Schema({  
    name: String,
}, { collection: 'shoptype' })
const User = module.exports = mongoose.model('shoptype', userSchema);