//models/shopsSchema.js
const mongoose = require('mongoose');
const usersSchema = mongoose.Schema({  
    name: String
}, { collection: 'role' })
const User = module.exports = mongoose.model('role', usersSchema);