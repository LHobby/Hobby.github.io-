//models/userSchema.js
const mongoose = require('mongoose');
const addressSchema = mongoose.Schema({  
    type: Number,
    username: String,
    detail: String,
    telephone: String
}, { collection: 'address' })
const Address = module.exports = mongoose.model('address', addressSchema);