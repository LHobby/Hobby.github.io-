var express = require('express');
var path = require('path')
var router = express.Router();
let bodyParser = require('body-parser')
let urlencodedParser = bodyParser.urlencoded({ extended: false })
let roleModel = require('../models/roleSchema');
const shopsSchema = require('../models/shopsSchema');

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.sendFile(path.join(__dirname, '../views/login.html'))
});
//显示用户列表功能
router.get('/list', (req, res) => { 
    // res.render('users',{ userlist:[] });
    // 第一步：
    // res.render('users',{ userlist:[{"username":"123","password":"456"}] });
    // 第二步:从数据库里查询出来
    roleModel.find((err, result) => {  
        //console.log(result)
        // {layout:false}
        res.render('role', { rolelist: result }); 
    })
});
//登录功能
router.post('/login', urlencodedParser, (req, res) => {
        let where = req.body
        userModel.findOne(where, (err, result) => {  
            console.log(result)
            if (result == null)    {
                // res.send('查询失败');  
                res.redirect('/')
            } else { 
                // res.send('查询成功'); 
                res.redirect('/home')
            }
        })
    })
    //添加功能
router.post('/add', urlencodedParser, (req, res) => {  
        userModel.findOne(where, (err, result) => {    
            if (result == null) {      
                // 1.添加的对象
                var duixiang = new userModel(req.body)        
                    // 2.向数据库添加
                duixiang.save((err, result) => {        
                    if (err) throw err        
                    console.log('添加成功');        
                    userModel.find((err, result) => {          
                        es.render('users', { userlist: result });        
                    })      
                })    
            } else {      
                // 返回注册页面 告知 该用户已存在
                res.redirect('/register')    
            }  
        })
    })
    //修改功能
router.post('/update', urlencodedParser, (req, res) => {
        //1、修改的条件
        // var where = {
        //         username: req.body.username,
        //         password: req.body.password,
        //     }
        //2、向数据库修改
        userModel.updateOne({ _id: req.body._id, }, req.body, (err, result) => {    
            if (err) throw err    
            console.log('修改成功');    
            // 查询新的用户信息 并显示在users.hbs文件中
            userModel.find((err, result) => {      
                res.render('users', { userlist: result });    
            })  
        })
    })
    //删除功能
router.post('/delete', urlencodedParser, (req, res) => {  
    // 1.删除的条件
    var where = { _id: require('mongodb').ObjectId(req.body._id) }    
        // 2.向数据库删除     
    userModel.deleteOne(where, (err, result) => {    
        if (err) throw err    
        console.log('删除成功');    
        // 查询新的用户信息 并显示在users.hbs文件中  
        userModel.find((err, result) => {      
            res.render('users', { userlist: result });    
        })  
    })
})
module.exports = router;