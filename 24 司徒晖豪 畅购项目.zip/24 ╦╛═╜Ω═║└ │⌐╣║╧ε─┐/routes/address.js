var express = require('express');
var router = express.Router();
let addressModel = require('./../models/addressSchema')
let bodyParser = require('body-parser')
let urlencodedParser = bodyParser.urlencoded({ extended: false })

// 显示用户列表功能
router.get('/list', (req, res) => {  
    // res.render('users',{ userlist:[] });
       // 第一步：
       // res.render('users',{ userlist:[{"username":"123","password":"456"}] });
       // 第二步：从数据库里查询出来
    addressModel.find((err, result) => {    
        res.render('address', { addresslist: result, total: result.length });  
    })
});

//添加功能
router.post('/add', urlencodedParser, (req, res) => {
    //1、添加的对象
    var duixiang = new addressModel(req.body)
        //2、向数据库添加
    duixiang.save((err, result) => {
        if (err) throw err
        console.log('添加成功');
        addressModel.find((err, result) => {
            res.render('address', { addresslist: result, total: result.length })
        })
    })
})

//删除功能
router.post('/delete', urlencodedParser, (req, res) => {  
    // 1.删除的条件
    var where = { _id: require('mongodb').ObjectId(req.body._id) }    
        // 2.向数据库删除     
    addressModel.deleteOne(where, (err, result) => {    
        if (err) throw err    
        console.log('删除成功');    
        // 查询新的用户信息 并显示在users.hbs文件中  
        addressModel.find((err, result) => {      
            res.render('address', { addresslist: result, total: result.length })   
        })  
    })
})
module.exports = router;