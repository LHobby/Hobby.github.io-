var express = require('express');
var path = require('path')
var router = express.Router();
let bodyParser = require('body-parser')
let urlencodedParser = bodyParser.urlencoded({ extended: false })
let roleModel = require('../models/roleSchema');
let powerModel = require('../models/powerSchema');
let userModel = require('./../models/userSchema');
const shopsSchema = require('../models/shopsSchema');

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.sendFile(path.join(__dirname, '../views/login.html'))
});
//显示用户列表功能
router.get('/list', (req, res) => { 
    // res.render('users',{ userlist:[] });
    // 第一步：
    // res.render('users',{ userlist:[{"username":"123","password":"456"}] });
    // 第二步:从数据库里查询出来
    userModel.find((err, userresult) => {  
        roleModel.find((err, roleresult) => {
                powerModel.find((err, powerresult) => {
                    let newlist = []
                    powerresult.forEach(powerduixiang => {
                        userresult.forEach((userduixiang, index) => {
                            if (userduixiang._id == powerduixiang.userid) {
                                powerduixiang.username = userduixiang.username
                            }
                        })
                        roleresult.forEach((roleduixiang, index) => {
                            if (roleduixiang._id == powerduixiang.userid) {
                                powerduixiang.rolename = roleduixiang.name
                            }
                        })
                        newlist.push(powerduixiang)
                    })
                    res.render('power', {
                        userlist: userresult,
                        rolelist: roleresult,
                        powerlist: newlist
                    })
                })
            })
            //console.log(result)
            // {layout:false}
            //res.render('power', { addresslist: result }); 
    })
});
//登录功能
router.post('/login', urlencodedParser, (req, res) => {
        let where = req.body
        userModel.find((err, userresult) => {  
            roleModel.find((err, roleresult) => {
                    powerModel.find((err, powerresult) => {
                        res.render('power', {
                            userlist: userresult,
                            rolelist: roleresult,
                            powerlist: powerresult
                        })
                    })
                })
                //console.log(result)
                // {layout:false}
                //res.render('power', { addresslist: result }); 
        })
    })
    //添加功能
router.post('/add', urlencodedParser, (req, res) => {
        var duixiang = new powerModel(req.body)  
        duixiang.save((err, result) => {    
            if (err) throw err    
            console.log("添加成功")    
            userModel.find((err, userresult) => {  
                roleModel.find((err, roleresult) => {
                    powerModel.find((err, powerresult) => {
                        let newlist = []
                        powerresult.forEach(powerduixiang => {
                            userresult.forEach((userduixiang, index) => {
                                if (userduixiang._id == powerduixiang.userid) {
                                    powerduixiang.username = userduixiang.username
                                }
                            })
                            roleresult.forEach((roleduixiang, index) => {
                                if (roleduixiang._id == powerduixiang.userid) {
                                    powerduixiang.rolename = roleduixiang.name
                                }
                            })
                            newlist.push(powerduixiang)
                        })
                        res.render('power', {
                            userlist: userresult,
                            rolelist: roleresult,
                            powerlist: newlist
                        })
                    })
                })
            })
        })

    })
    //修改功能
router.post('/update', urlencodedParser, (req, res) => {
        //1、修改的条件
        // var where = {
        //         username: req.body.username,
        //         password: req.body.password,
        //     }
        //2、向数据库修改
        userModel.updateOne({ _id: req.body._id, }, req.body, (err, result) => {    
            if (err) throw err    
            console.log('修改成功');    
            // 查询新的用户信息 并显示在users.hbs文件中
            powerModel.find((err, userresult) => {  
                roleModel.find((err, roleresult) => {
                        powerModel.find((err, powerresult) => {
                            res.render('power', {
                                userlist: userresult,
                                rolelist: roleresult,
                                powerlist: powerresult
                            })
                        })
                    })
                    //console.log(result)
                    // {layout:false}
                    //res.render('power', { addresslist: result }); 
            })
        })
    })
    //删除功能
router.post('/delete', urlencodedParser, (req, res) => {  
    // 1.删除的条件
    var where = { _id: require('mongodb').ObjectId(req.body._id) }    
        // 2.向数据库删除     
    userModel.deleteOne(where, (err, result) => {    
        if (err) throw err    
        console.log('删除成功');    
        // 查询新的用户信息 并显示在users.hbs文件中  
        powerModel.find((err, userresult) => {  
            roleModel.find((err, roleresult) => {
                    powerModel.find((err, powerresult) => {
                        res.render('power', {
                            userlist: userresult,
                            rolelist: roleresult,
                            powerlist: powerresult
                        })
                    })
                })
                //console.log(result)
                // {layout:false}
                //res.render('power', { addresslist: result }); 
        })
    })
})
module.exports = router;