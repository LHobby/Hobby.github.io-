let express = require('express')
let router = express.Router()

// post请求引用的模块
let bodyParser = require('body-parser')
let urlencodedParser = bodyParser.urlencoded({ extended: false })

// 文件上传功能引用的模块
let fs = require('fs')

// 得到数据库中推荐的所有数据 127.0.0.1:8080/gettuijian 能出来的数据
const TuiJianModel = require('../module/tuijianmodel')
const { url } = require('inspector')
    // router.get('/list', (req, res) => {
    //     MogodbClient.connect(url, (err, db) => {
    //         if (err) throw err
    //         let dbo = db.db('music')
    //             // dbo = 数据库操作 o = operate操作 collection集合 find({查找条件})查找 toArray转数组
    //         dbo.collection('tuijian').find().toArray((err, result) => {
    //             if (err) throw err
    //             res.send(JSON.stringify(result))
    //             db.close()
    //         })
    //     })
    // })
router.get('/list', (req, res) => {
    TuiJianModel.find({}, (err, result) => {
        if (err) throw err
        res.send(JSON.stringify(result))
    })
})

// 删除功能
router.post('/delete', urlencodedParser, (req, res) => {
    let id = req.body._id
    let whereStr = {
            _id: require('mongodb').ObjectId(id)
        }
        // 删除条件
    TuiJianModel.deleteOne(whereStr, (err, result) => {
        if (err) throw err
        console.log('删除成功');
        res.redirect('/manager?2')
    })
})

// 修改功能
router.post('/edit', urlencodedParser, (req, res) => {
    let files = req.files
    if (files == null) { // 没有上传过来的图片
        let whereStr = {
            '_id': require('mongodb').ObjectId(req.body._id),
            'title': req.body.title,
            'singer': req.body.singer
        }
        TuiJianModel.updateOne(whereStr, (err, result) => {
            if (err) throw err
            console.log('修改成功');
            res.redirect('/manager?2')
        })
    } else {
        // 如果传过来的是 mp3 上传音乐 修改字段 mp3
    }
})

// 文件上传功能
router.post('/add', urlencodedParser, (req, res) => {
    let files = req.files
    let oldPath = files[0].destination + files[0].filename //旧的地址
    let newPath = './public/img/' + files[0].originalname //新的地址
    fs.rename(oldPath, newPath, (err, result) => { //rename重写
        if (err) throw err
        console.log('文件上传成功');
        let oldPath2 = files[1].destination + files[1].filename //旧的地址
        let newPath2 = './public/img/' + files[1].originalname //新的地址
        fs.rename(oldPath2, newPath2, (err, result) => {
            if (err) throw err
            console.log('文件上传成功');
            // 2.往数据库中写入一条数据
            let whereStr = {
                    'haibao': './img/' + files[0].originalname,
                    'title': req.body.title,
                    'num': 0,
                    'singer': req.body.singer,
                    'mp3': './img/' + files[1].originalname,
                } //添加条件
                // 1.新建一个对象
            let duixiang = new TuiJianModel(whereStr) // 2.插入数据库save保存方法
                // 2.插入数据库save保存方法
            duixiang.save((err, result) => {
                if (err) throw err
                console.log('添加成功')
                res.redirect('/manager?2')
            })
        })
    })
})

module.exports = router